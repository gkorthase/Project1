
/**
 * Calculating the bill for a desk.
 * Gabe Korthase 
 * 2015.01.26.01
 */
public class DeskBill {
    private int totalPrice, drawerNum, length, width;
    private String wood, customer, order;

    /**
     * Name of customer and order number.
     */
    public DeskBill(String name, String orderNum) {
        customer = name;
        order = orderNum;
        totalPrice = 0;
    }

    /**
     * Type of wood desk will be built from.
     * "mahogany", "oak", or "pine"
     */
    public void setWood(String woodType) {
        wood = woodType;
    }
    
    /**
     * How wide will the desk be?
     */
    public void setWidth(int width) {
        this.width = width;
    }
    
    /**
     * How long will the desk be?
     */
    public void setLength(int length) {
        this.length = length;
    }
    
    /**
     * How many drawers?
     */
    public void setDrawers(int drawerNum) {
        this.drawerNum = drawerNum;
    }
    
    /**
     * 
     */
    public void calculateBill() {
        final int MIN_CHARGE = 200;
        final int BIG_DESK =750;
        final int BIG_CHARGE = 50;
        final int MAHOGANY = 150;
        final int OAK = 125;
        final int PINE = 0;
        final int DRAWER = 30;
        int size = width * length;
        totalPrice = MIN_CHARGE;
        if(size >= BIG_DESK) {
            totalPrice = totalPrice + BIG_CHARGE;
        }
        if(wood == "mahogany") {
            totalPrice = totalPrice + MAHOGANY;
        } else if(wood == "oak") {
            totalPrice = totalPrice + OAK;
        } else {
            totalPrice = totalPrice + PINE;
        }
        totalPrice = totalPrice + (drawerNum * DRAWER);
    }
    
     /**
     * Print out a receipt.
     */
    public void printReceipt()
    {
        System.out.println("Customer Name: " + customer);
        System.out.println("Order Number: " + order);
        System.out.println("Total price of desk is : $" + totalPrice);
    }
}
